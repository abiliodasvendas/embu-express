import{j as s,n as t}from"./index-go1tVo7H.js";function m({className:e,...n}){return s.jsx("div",{className:t("animate-pulse rounded-md bg-muted",e),...n})}export{m as S};
