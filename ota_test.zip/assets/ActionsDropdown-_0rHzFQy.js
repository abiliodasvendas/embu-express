import{z as n,j as s,B as c,n as r,bQ as y,bR as k,bS as m,bT as j}from"./index-go1tVo7H.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=n("EllipsisVertical",[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"12",cy:"5",r:"1",key:"gxeob9"}],["circle",{cx:"12",cy:"19",r:"1",key:"lyex9k"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=n("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);function w({actions:o,triggerClassName:t="h-8 w-8 p-0",triggerSize:l="sm",align:d="end",disabled:x=!1,children:h}){const a=o.filter(e=>!e.hidden);return a.length===0||x?s.jsx(c,{variant:"ghost",size:l,className:r("text-gray-300 cursor-not-allowed",t),disabled:!0,children:s.jsx(i,{className:"h-4 w-4"})}):s.jsxs(y,{children:[s.jsx(k,{asChild:!0,children:h||s.jsx(c,{variant:"ghost",size:l,className:r("text-gray-400 hover:text-gray-600",t),onClick:e=>e.stopPropagation(),children:s.jsx(i,{className:"h-4 w-4"})})}),s.jsx(m,{align:d,children:a.map((e,p)=>s.jsxs(j,{onClick:u=>{u.stopPropagation(),e.onClick()},disabled:e.disabled,className:r("cursor-pointer",e.isDestructive&&"text-red-600 focus:text-red-600",e.variant==="destructive"&&"text-red-600 focus:text-red-600"),title:e.title,children:[e.icon&&s.jsx("span",{className:r("mr-2 h-4 w-4",e.isDestructive?"text-red-600":""),children:e.icon}),e.label]},`${e.label}-${p}`))})]})}export{w as A,i as E,v as T};
