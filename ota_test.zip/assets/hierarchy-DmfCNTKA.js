import{a0 as f}from"./index-go1tVo7H.js";function M(u,n){return!u||!n?!1:u===f.SUPER_ADMIN?!0:u===f.ADMIN?!(n===f.SUPER_ADMIN||n===f.ADMIN):!(n===f.SUPER_ADMIN||n===f.ADMIN)}export{M as c};
